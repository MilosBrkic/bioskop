/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kontroler;

import domain.Distributer;
import domain.Film;
import domain.Karta;
import domain.Projekcija;
import domain.Sala;
import domain.Zanr;
import domain.Zaposleni;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.LinkedList;
import transfer.Operation;
import transfer.Request;
import transfer.Response;
import transfer.ResponseStatus;

/**
 *
 * @author milos
 */
public class Kontroler {

    private static Kontroler instance;   
    private Socket soket;    
    private ObjectInputStream in;
    private ObjectOutputStream out;   
    private Zaposleni zaposleni = null;

    private Kontroler() {
                      
    }
    
    public static Kontroler getInstance(){
        if(instance == null)
            instance = new Kontroler();
        
        return instance;
    }

    public void setSoket(Socket soket) throws IOException {
        this.soket = soket;
        out = new ObjectOutputStream(soket.getOutputStream());
        in = new ObjectInputStream(soket.getInputStream());       
    }
    
    public LinkedList<Film> ucitajFilmove() throws Exception{
       
        Request request = new Request(null, Operation.ucitajFilmove);
        out.writeObject(request);
        Response response = (Response) in.readObject();

        if(response.getStatus() == ResponseStatus.ERROR)
            throw new Exception(response.getErrorMessage());

        return (LinkedList<Film>) response.getData();      
    }
    
    public LinkedList<Film> pronadjiFilmove(Film uslov) throws Exception{
        
        Request request = new Request(uslov, Operation.pronadjiFilmove);
        out.writeObject(request);
        Response response = (Response) in.readObject();

        if(response.getStatus() == ResponseStatus.ERROR)
            throw new Exception(response.getErrorMessage());
        
        return (LinkedList<Film>) response.getData();
    }
    
    public LinkedList<Zanr> ucitajZanrove() throws Exception{
        
        Request request = new Request(null, Operation.ucitajZanrove);
        out.writeObject(request);
        Response response = (Response) in.readObject();

        if(response.getStatus() == ResponseStatus.ERROR)
            throw new Exception(response.getErrorMessage());

        return (LinkedList<Zanr>) response.getData();
    }

    public LinkedList<Projekcija> ucitajProjekcije() throws Exception{
        
        Request request = new Request(null, Operation.ucitajProjekcije);
        out.writeObject(request);          
        Response response = (Response) in.readObject();

        if(response.getStatus() == ResponseStatus.ERROR)
           throw new Exception(response.getErrorMessage());

        return (LinkedList<Projekcija>) response.getData();
    }
    
    public void obrisiProjekciju(Projekcija projekcija) throws Exception{
        
        Request request = new Request(projekcija, Operation.obrisiProjekciju);
        out.writeObject(request);          
        Response response = (Response) in.readObject();           
            
       if(response.getStatus() == ResponseStatus.ERROR)
            throw new Exception(response.getErrorMessage());
    }
    
    public LinkedList<Projekcija> pronadjiProjekcije(Projekcija uslov) throws Exception{

        Request request = new Request(uslov, Operation.pronadjiProjekcije);
        out.writeObject(request);
        Response response = (Response) in.readObject();

        if(response.getStatus() == ResponseStatus.ERROR)
            throw new Exception(response.getErrorMessage());

        return (LinkedList<Projekcija>) response.getData();
    }

    public LinkedList<Sala> ucitajSale() throws Exception{

        Request request = new Request(null, Operation.ucitajSale);
        out.writeObject(request);          
        Response response = (Response) in.readObject();
        
        if(response.getStatus() == ResponseStatus.ERROR)
            throw new Exception(response.getErrorMessage());
        
        return (LinkedList<Sala>) response.getData();      
    }

    public LinkedList<Distributer> ucitajDistributere() throws Exception {
        
        Request request = new Request(null, Operation.ucitajDistributere);
        out.writeObject(request);          
        Response response = (Response) in.readObject();

        if(response.getStatus() == ResponseStatus.ERROR)
            throw new Exception(response.getErrorMessage());

        return (LinkedList<Distributer>) response.getData();   
    }

    public void dodajSalu(Sala sala) throws Exception{
        
        Request request = new Request(sala, Operation.zapamtiSalu);
        out.writeObject(request);          
        Response response = (Response) in.readObject();           
        
        if(response.getStatus() == ResponseStatus.ERROR)
            throw new Exception(response.getErrorMessage());         
    }
    
    public void obrisiSalu(Sala sala) throws Exception{
        
        Request request = new Request(sala, Operation.obrisiSalu);
        out.writeObject(request);          
        Response response = (Response) in.readObject();       

        if(response.getStatus() == ResponseStatus.ERROR)
            throw new Exception(response.getErrorMessage());        
    }
    
    public void zapamtiFilm(Film film) throws Exception{
        
        Request request = new Request(film, Operation.zapamtiFilm);

        out.reset();
        out.writeObject(request);

        Response response = (Response) in.readObject(); 
            
        if(response.getStatus() == ResponseStatus.ERROR)
            throw new Exception(response.getErrorMessage());
    }
    
    public void obrisiFilm(Film film) throws Exception{
        
        Request request = new Request(film, Operation.obrisiFilm);
        out.writeObject(request);          
        Response response = (Response) in.readObject();    

        if(response.getStatus() == ResponseStatus.ERROR)
            throw new Exception(response.getErrorMessage());        
    }

    public void zapamtiProjekciju(Projekcija projekcija) throws Exception{
        
        Request request = new Request(projekcija, Operation.zapamtiProjekciju);           
        out.reset();
        out.writeObject(request);
        Response response = (Response) in.readObject(); 

        if(response.getStatus() == ResponseStatus.ERROR)
            throw new Exception(response.getErrorMessage());               
    }
           
    public Zaposleni prijava(String ime, String lozinka) throws Exception{
        
        Zaposleni zap = new Zaposleni(ime, lozinka);
        Request request = new Request(zap, Operation.prijava);
        out.writeObject(request);          
        Response response = (Response) in.readObject();

        if(response.getStatus() == ResponseStatus.ERROR)
            throw new Exception(response.getErrorMessage());

        this.zaposleni = (Zaposleni) response.getData();
        return this.zaposleni;
    }   

    public LinkedList<Karta> ucitajKarte(Projekcija projekcija) throws Exception {

        Request request = new Request(projekcija, Operation.ucitajKarte);
        out.writeObject(request);          
        Response response = (Response) in.readObject();

        if(response.getStatus() == ResponseStatus.ERROR)
            throw new Exception(response.getErrorMessage());

        return (LinkedList<Karta>) response.getData();
    }
    
    public void zapamtiKartu(Karta karta) throws Exception{
        karta.setZaposleni(zaposleni);
        
        Request request = new Request(karta, Operation.zapamtiKartu);           
        out.reset();
        out.writeObject(request);
        Response response = (Response) in.readObject(); 

        if(response.getStatus() == ResponseStatus.ERROR)
            throw new Exception(response.getErrorMessage()); 
       
    }
}

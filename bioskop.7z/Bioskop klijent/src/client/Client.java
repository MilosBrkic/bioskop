/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import gui.Prijava;
import java.io.IOException;
import java.net.Socket;
import javax.swing.JOptionPane;
import kontroler.Kontroler;

/**
 *
 * @author milos
 */
public class Client {
    
    public static void main(String[] args) {
        while(true){
            try {
                Socket soket = new Socket("localhost",9000);
                Kontroler.getInstance().setSoket(soket);           
                new Prijava().setVisible(true);
                return;
            } catch (IOException ex) {
                int odgovor = JOptionPane.showConfirmDialog(null, "Konekcija se serverom nije uspostavljena.\nPokušati ponovo?", "Greška", 
                        JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);

                if(odgovor != 0)
                    return;
            }
        }
    }
    
}

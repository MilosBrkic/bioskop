/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui.model;

import domain.Zanr;
import java.util.LinkedList;
import javax.swing.AbstractListModel;

/**
 *
 * @author milos
 */
public class ZanrListModel extends AbstractListModel  {
    
    private LinkedList<Zanr> zanrovi;

    public ZanrListModel(LinkedList<Zanr> zanrovi) {
        this.zanrovi = zanrovi;
    }

   public void addZanr(Zanr zanr){
       if(zanrovi != null)
           zanrovi.add(zanr);
   }

    public LinkedList<Zanr> getZanrovi() {
        return zanrovi;
    }
    
    public void removeZanr(int index){
        if(zanrovi != null && !zanrovi.isEmpty() && index>=0 && index<zanrovi.size())
            zanrovi.remove(index);
    }

    @Override
    public int getSize() {
        if(zanrovi != null)
            return zanrovi.size();
        else
            return 0;
    }

    @Override
    public Object getElementAt(int index) {
        if(index >= 0)
            return zanrovi.get(index);
        else
            return null;
    }
    
}

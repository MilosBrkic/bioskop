/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui.model;

import domain.Sala;
import java.util.LinkedList;
import javax.swing.AbstractListModel;

/**
 *
 * @author milos
 */
public class SalaListModel extends AbstractListModel  {
    
    private LinkedList<Sala> Sale;

    public SalaListModel(LinkedList<Sala> Sale) {
        this.Sale = Sale;
    }

   public void addsala(Sala sala){
       if(Sale != null)
           Sale.add(sala);
   }

    public LinkedList<Sala> getSale() {
        return Sale;
    }
    
    public void removeSala(int index){
        if(Sale != null && !Sale.isEmpty() && index>=0 && index<Sale.size())
            Sale.remove(index);
    }

    @Override
    public int getSize() {
        if(Sale != null)
            return Sale.size();
        else
            return 0;
    }

    @Override
    public Object getElementAt(int index) {
        if(index >= 0)
            return Sale.get(index);
        else
            return null;
    }
    
}

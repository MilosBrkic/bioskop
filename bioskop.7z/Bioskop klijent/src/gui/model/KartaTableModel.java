/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui.model;

import domain.Karta;
import java.util.LinkedList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author milos
 */
public class KartaTableModel extends AbstractTableModel {

    private LinkedList<Karta> karte;
    private final String[] kolone = new String[]{"Red","Sedište","Cena","Status"};

    public KartaTableModel(LinkedList<Karta> karte) {
        this.karte = karte;
    }

    public KartaTableModel() {
    }
      
    
    
    @Override
    public int getRowCount() {
        if(karte != null)
            return karte.size();
        else
            return 0;
    }

    @Override
    public int getColumnCount() {
        return kolone.length;
    }
    
    @Override
    public String getColumnName(int column) {
        return kolone[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Karta Karta = karte.get(rowIndex);
        
        switch(columnIndex)
        {
            case 0: return Karta.getBrojReda();
            case 1: return Karta.getBrojSedista();
            case 2: return Karta.getCena();
            case 3: return Karta.getStatus();
            default: return "null";
        }
        
    }
    
    public Karta getKartaAt(int index){
        if(karte != null && index>=0 && index<karte.size())
            return karte.get(index);
        else
            return null;
    }
    
    public void dodajKartu(Karta karta){
        if(karta != null)
            karte.add(karta);
    }
}

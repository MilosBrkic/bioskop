/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui.model;

import domain.Projekcija;
import java.text.SimpleDateFormat;
import java.util.LinkedList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author milos
 */
public class ProjekcijaTableModel extends AbstractTableModel {

    private LinkedList<Projekcija> projekcije;
    private final String[] kolone = new String[]{"ID","Film","Sala","Vreme","Datum"};

    public ProjekcijaTableModel() {
    }

    public ProjekcijaTableModel(LinkedList<Projekcija> projekcije) {
        this.projekcije = projekcije;
    }
         
    @Override
    public int getRowCount() {
        if(projekcije != null)
            return projekcije.size();
        else
            return 0;
    }

    @Override
    public int getColumnCount() {
        return kolone.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Projekcija p = projekcije.get(rowIndex);
        switch(columnIndex){
            case 0: return p.getId();
            case 1: return p.getFilm().getNaziv();
            case 2: return p.getSala().getBrojSale();
            case 3: return new SimpleDateFormat("HH:mm").format(p.getVreme());
            case 4: return new SimpleDateFormat("dd.MM.yyyy.").format(p.getDatum());
            
            default: return "null";
        }
    }

    @Override
    public String getColumnName(int column) {
        return kolone[column];
    }
    
    public void removeProjekcija(int index){
        if(projekcije != null && !projekcije.isEmpty() && index>=0 && index<projekcije.size())
            projekcije.remove(index);
    }
    
    public Projekcija getProjekcijaAt(int index){
        if(projekcije != null && index>=0 && index<projekcije.size())
            return projekcije.get(index);
        else
            return null;
    }
}

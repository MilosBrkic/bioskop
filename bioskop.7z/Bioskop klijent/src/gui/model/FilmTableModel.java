/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui.model;

import domain.Film;
import java.util.LinkedList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author milos
 */
public class FilmTableModel extends AbstractTableModel {

    private LinkedList<Film> filmovi;
    private final String[] kolone = new String[]{"ID","Naziv","Trajanje (min)","Distributer","Aktivan"};

    public FilmTableModel(LinkedList<Film> filmovi) {
        this.filmovi = filmovi;
    }
      
    
    @Override
    public int getRowCount() {
        if(filmovi != null)
            return filmovi.size();
        else
            return 0;
    }

    @Override
    public int getColumnCount() {
        return kolone.length;
    }
    
    @Override
    public String getColumnName(int column) {
        return kolone[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Film film = filmovi.get(rowIndex);
        
        switch(columnIndex)
        {
            case 0: return film.getId(); 
            case 1: return film.getNaziv();
            case 2: return film.getTrajanje();
            case 3: return film.getDistributer();
            case 4: return film.isAktivan();
            default: return "null";
        }
        
    }
    
    public void removeFilm(int index){
        if(filmovi != null && !filmovi.isEmpty() && index>=0 && index<filmovi.size())
            filmovi.remove(index);
    }
    
    public Film getFilmAt(int index){
        if(filmovi != null && index>=0 && index<filmovi.size())
            return filmovi.get(index);
        else
            return null;
    }
    
}

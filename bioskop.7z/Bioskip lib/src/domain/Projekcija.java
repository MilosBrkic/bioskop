/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Date;
import java.text.SimpleDateFormat;

/**
 *
 * @author milos
 */
public class Projekcija extends DomenskiObjekat{
    
    private int id;
    private Film film;
    private Sala sala;
    private Date datum;
    private Time vreme;

    public Projekcija(Film film, Sala sala, Date datum, Time vreme) {
        this.film = film;
        this.sala = sala;
        this.datum = datum;
        this.vreme = vreme;
    }

    public Time getVreme() {
        return vreme;
    }

    public void setVreme(Time vreme) {
        this.vreme = vreme;
    }

    public Projekcija() {
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Film getFilm() {
        return film;
    }

    public void setFilm(Film film) {
        this.film = film;
    }

    public Sala getSala() {
        return sala;
    }

    public void setSala(Sala sala) {
        this.sala = sala;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    @Override
    public String toString() {
        return new SimpleDateFormat("dd.MM.yyyy.").format(datum)+" "+film.getNaziv()+" u "+vreme+" sala "+sala.getBrojSale();
    }
    
    

    @Override
    public String getNazivTabele() {
        return "projekcije";
    }

    @Override
    public String getVrednostiAtributa() {
        return "("+film.getId()+","+sala.getBrojSale()+",'"+datum+"','"+vreme+"')";
    }

    @Override
    public String getKolone() {
        return "(film, sala, datum, vreme)";
    }

    @Override
    public boolean postaviVrednosti(ResultSet rs) {
        try {
            id = rs.getInt("id");

            film  = new Film();
            film.setId(rs.getInt("film"));

            sala = new Sala();
            sala.setBrojSale(rs.getInt("sala"));

            datum = rs.getDate("datum");
            vreme = rs.getTime("vreme");

            return true;
        } catch (SQLException ex) {
            return false;
        }       
    }

    @Override
    public String uslovPretrage() {
        if(sala != null &&  datum != null)//za validaciju jedinstvene projekcije   
            return "sala = "+sala.getBrojSale()+" AND datum = '"+datum+"'";
        
        if(sala != null)//za validaciju brisanja sale         
            return "sala = "+sala.getBrojSale();
        
        if(film != null && film.getId() != 0)//za validaciju brisanja filma
            return "film = "+film.getId();
               
        if(datum == null)//pretraga
            return "film IN (SELECT id FROM filmovi WHERE naziv LIKE '%"+film.getNaziv()+"%')";
        else              
            return "datum = '"+datum+"' AND film IN (SELECT id FROM filmovi WHERE naziv LIKE '%"+film.getNaziv()+"%')";
    }

    @Override
    public String uslovIdentifikacije() {
        return "id = "+id;
    }

    @Override
    public String uslovAzururanja() {
        return "film = "+film.getId()+", sala = "+sala.getBrojSale()+", datum = '"+datum+"', vreme = '"+vreme+"'";
    }
    
  
}

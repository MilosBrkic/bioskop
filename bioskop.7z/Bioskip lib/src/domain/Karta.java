/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author milos
 */
public class Karta extends DomenskiObjekat{
    
    private int brojReda;
    private int brojSedista; //u redu
    private Projekcija projekcija;
    private BigDecimal cena;
    private Zaposleni zaposleni;
    private String status;

    public Karta(int brojReda, int brojSedista, Projekcija projekcija, BigDecimal cena, Zaposleni zaposleni, String status) {
        this.brojReda = brojReda;
        this.brojSedista = brojSedista;
        this.projekcija = projekcija;
        this.cena = cena;
        this.zaposleni = zaposleni;
        this.status = status;
    }

    public Karta() {
    }
    
    

    public int getBrojReda() {
        return brojReda;
    }

    public void setBrojReda(int brojReda) {
        this.brojReda = brojReda;
    }

    public int getBrojSedista() {
        return brojSedista;
    }

    public void setBrojSedista(int brojSedista) {
        this.brojSedista = brojSedista;
    }

    public Projekcija getProjekcija() {
        return projekcija;
    }

    public void setProjekcija(Projekcija projekcija) {
        this.projekcija = projekcija;
    }

    public BigDecimal getCena() {
        return cena;
    }

    public void setCena(BigDecimal cena) {
        this.cena = cena;
    }

    public Zaposleni getZaposleni() {
        return zaposleni;
    }

    public void setZaposleni(Zaposleni zaposleni) {
        this.zaposleni = zaposleni;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String getNazivTabele() {
        return "karte";
    }

    @Override
    public String getVrednostiAtributa() {
        return "("+brojReda+", "+brojSedista+", "+projekcija.getId()+", "+cena+", "+zaposleni.getId()+", '"+status+"')";
    }

    @Override
    public String getKolone() {
        return "(broj_reda, broj_sedista, projekcija, cena, zaposleni, status)";
    }

    @Override
    public boolean postaviVrednosti(ResultSet rs) {      
        try {
            brojReda = rs.getInt("broj_reda");
            brojSedista = rs.getInt("broj_sedista");
            
            projekcija = new Projekcija();
            projekcija.setId(rs.getInt("projekcija"));
            
            zaposleni = new Zaposleni();
            zaposleni.setId(rs.getInt("zaposleni"));
            
            cena = rs.getBigDecimal("cena");
            status = rs.getString("status");
            
            return true;
        } catch (SQLException ex) {
            return false;
        }
    }

    @Override
    public String uslovPretrage() {
        return "projekcija = "+projekcija.getId();
    }

    @Override
    public String uslovIdentifikacije() {
        return "broj_reda = "+brojReda+" AND broj_sedista = "+brojSedista+" AND projekcija = "+projekcija.getId();
    }

    @Override
    public String uslovAzururanja() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setId(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
 
}

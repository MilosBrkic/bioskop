/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.io.Serializable;
import java.sql.ResultSet;

/**
 *
 * @author milos
 */
public abstract class DomenskiObjekat implements Serializable{
    

    public abstract String getNazivTabele();
   
    public abstract String getVrednostiAtributa();
    
    public abstract String getKolone();
        
    public abstract boolean postaviVrednosti(ResultSet rs );
    
    public abstract String uslovPretrage();
    
    public abstract String uslovIdentifikacije();
    
    public abstract String uslovAzururanja();
    
    public abstract void setId(int id);
      
}

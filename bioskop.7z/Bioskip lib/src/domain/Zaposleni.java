/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author milos
 */
public class Zaposleni extends DomenskiObjekat{
    
    private int id;
    private String username;
    private String password;
    private String imePrezime;
    private String brojTelefona;
    private String status;

    public Zaposleni(int id, String username, String password, String imePrezime, String brojTelefona, String status) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.imePrezime = imePrezime;
        this.brojTelefona = brojTelefona;
        this.status = status;
    }

    public Zaposleni(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public Zaposleni() {
    }
    
       
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getImePrezime() {
        return imePrezime;
    }

    public void setImePrezime(String imePrezime) {
        this.imePrezime = imePrezime;
    }

    public String getBrojTelefona() {
        return brojTelefona;
    }

    public void setBrojTelefona(String brojTelefona) {
        this.brojTelefona = brojTelefona;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String getNazivTabele() {
        return "zaposleni";
    }

    @Override
    public String getVrednostiAtributa() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getKolone() {
        return "(username, password, ime_prezime, telefon, status)";
    }

    @Override
    public boolean postaviVrednosti(ResultSet rs) {
        try {
            id = rs.getInt("id");
            username = rs.getString("username");
            //password = rs.getString("password");
            imePrezime = rs.getString("ime_prezime");
            brojTelefona = rs.getString("telefon");
            status = rs.getString("status");
            return true;
        } catch (SQLException ex) {
            return false;
        }
    }

    @Override
    public String uslovPretrage() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String uslovIdentifikacije() {
        if(id != 0)
            return "id ="+id;
        else
            return "username = '"+username+"' AND password = '"+password+"'";
    }

    @Override
    public String uslovAzururanja() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}

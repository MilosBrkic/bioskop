/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;

/**
 *
 * @author milos
 */
public class Film extends DomenskiObjekat{
    
    private int id;
    private String naziv;
    private int trajanje;//u minutima
    private LinkedList<Zanr> zanrovi;
    private Distributer distributer;
    private boolean aktivan;

    public Film(String naziv, int trajanje, LinkedList<Zanr> zanrovi, Distributer distributer, boolean aktivan) {
        this.naziv = naziv;
        this.trajanje = trajanje;
        this.zanrovi = zanrovi;
        this.distributer = distributer;
        this.aktivan = aktivan;
    }

    public Film() {
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public int getTrajanje() {
        return trajanje;
    }

    public void setTrajanje(int trajanje) {
        this.trajanje = trajanje;
    }

    public LinkedList<Zanr> getZanrovi() {
        return zanrovi;
    }

    public void setZanrovi(LinkedList<Zanr> zanrovi) {
        this.zanrovi = zanrovi;
    }

    public Distributer getDistributer() {
        return distributer;
    }

    public void setDistributer(Distributer distributer) {
        this.distributer = distributer;
    }

    public boolean isAktivan() {
        return aktivan;
    }

    public void setAktivan(boolean aktivan) {
        this.aktivan = aktivan;
    }

    @Override
    public String toString() {
        return naziv;
    }

    @Override
    public String getNazivTabele() {
        return "filmovi";
    }

    @Override
    public String getVrednostiAtributa() {
        return "('"+naziv+"',"+trajanje+","+distributer.getId()+","+aktivan+")";
    }

    @Override
    public String getKolone() {
        return "(naziv, trajanje, distributer, aktivan)";
    }

    
    
    @Override
    public boolean postaviVrednosti(ResultSet rs) {
        try {
            id = rs.getInt("id");
            naziv = rs.getString("naziv");
            trajanje = rs.getInt("trajanje");
            distributer = new Distributer();
            distributer.setId(rs.getInt("distributer"));//kasnije ce biti ucitan ceo distributer
            aktivan = rs.getBoolean("aktivan");
            
            return true;
        } catch (SQLException ex) {
            return false;
        }

    }

    @Override
    public String uslovPretrage() {
        if(zanrovi == null)
            return "naziv LIKE '%"+naziv+"%' AND aktivan = "+aktivan;
        
        Zanr zanr = zanrovi.getFirst();
        return "naziv LIKE '%"+naziv+"%' AND aktivan = "+aktivan+" AND id IN (SELECT film from pripadnost_zanru WHERE zanr = "+zanr.getId()+")";
    }

    @Override
    public String uslovIdentifikacije() {
        return "id = "+id;
    }

    @Override
    public String uslovAzururanja() {
        return "naziv = '"+naziv+"', trajanje = "+trajanje+", distributer = "+distributer.getId()+", aktivan = "+aktivan;
    }
    
       
}

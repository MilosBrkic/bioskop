/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author milos
 */
public class Zanr extends DomenskiObjekat{

    private int id;
    private String naziv;

    public Zanr(int zanrID, String nazivZanra) {
        this.id = zanrID;
        this.naziv = nazivZanra;
    }

    public Zanr() {
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    

    @Override
    public String toString() {
        return naziv;
    }

    @Override
    public boolean equals(Object obj) {
        if(obj == null)
            return false;
        
        return ((Zanr)obj).id == id;
    }

    @Override
    public String getNazivTabele() {
        return "zanrovi";
    }

    @Override
    public String getVrednostiAtributa() {
        return "("+id+","+naziv+")";
    }

    @Override
    public String getKolone() {
        return "(naziv)";
    }

    
    
    @Override
    public boolean postaviVrednosti(ResultSet rs) {
        try {
            id = rs.getInt("id");
            naziv = rs.getString("naziv");
            
            return true;
        } catch (SQLException ex) {
            return false;
        }
    }

    @Override
    public String uslovPretrage() {
        return "id ="+id;
    }

    @Override
    public String uslovIdentifikacije() {
        return "id ="+id;
    }

    @Override
    public String uslovAzururanja() {
        return "naziv = "+naziv;
    }
     
    
}

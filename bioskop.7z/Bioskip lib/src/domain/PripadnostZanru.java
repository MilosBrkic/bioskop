/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author milos
 */
public class PripadnostZanru extends DomenskiObjekat{
    
    private int zanrID;
    private int filmID;

    public PripadnostZanru() {
    }

    
    
    public PripadnostZanru(int zanrID, int filmID) {
        this.zanrID = zanrID;
        this.filmID = filmID;
    }

    public int getZanrID() {
        return zanrID;
    }

    public void setZanrID(int zanrID) {
        this.zanrID = zanrID;
    }

    public int getFilmID() {
        return filmID;
    }

    public void setFilmID(int filmID) {
        this.filmID = filmID;
    }
    
    

    @Override
    public String getNazivTabele() {
        return "pripadnost_zanru";
    }

    @Override
    public String getVrednostiAtributa() {
        return "("+zanrID+","+filmID+")";
    }

    @Override
    public String getKolone() {
        return "(zanr,film)";
    }
    
    

    @Override
    public boolean postaviVrednosti(ResultSet rs) {
        try {
            zanrID = rs.getInt("zanr");
            filmID = rs.getInt("film");
            
            return true;
        } catch (SQLException ex) {
            return false;
        }
    }

    @Override
    public String uslovPretrage() {
        return "film = "+filmID;
    }

    @Override
    public String uslovIdentifikacije() {
        return "film = "+filmID+" AND zanr = "+zanrID;
    }

    @Override
    public void setId(int id) {
        //
    }

    @Override
    public String uslovAzururanja() {
        return null;
    }
    
      
}

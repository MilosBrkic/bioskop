/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connection;

import database.DBBroker;
import domain.Zaposleni;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author milos
 */
public class Server extends Thread{
    
    private boolean signal = true;
    private ServerSocket serverSocket;
    private LinkedList<Client> klijenti = new LinkedList<>();
       
    public Server() throws Exception{
        DBBroker.close();

        if(!DBBroker.getInstance().checkConnection())
           throw new Exception("Server nije uspeo da se poveže sa bazom.");
    }
    
    @Override
    public void run() {      
        try {
            serverSocket = new ServerSocket(9000);
            System.out.println("Server je pokrenut");
            
            while(signal){
                Socket klijent = serverSocket.accept();
                Client nit = new Client(klijent,this);
                klijenti.add(nit);
                nit.start();
                System.out.println("Konekcija je uspostavljena");
            }
        } catch (IOException ex) {
            System.out.println("Server je zaustavljen");
        }
    }
    
    public void stopServer(){
        try {
            signal = false;
            serverSocket.close();
 
            for(Client c : klijenti){
                if(c.isAlive())
                    c.stopClient();
            }
            
        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public boolean isLogged(String username){
        for(Client c : klijenti){
                if(c.isAlive() && c.getZaposleni() != null && c.getZaposleni().getUsername().equals(username))
                    return true;                       
            }
        return false;
    }

    public LinkedList<Zaposleni> getZaposleni() {
        LinkedList<Zaposleni> zaposleni = new LinkedList<>();
        
        for(Client c : klijenti)
            if(c.getZaposleni() != null && c.isAlive())
                zaposleni.add(c.getZaposleni());
        
        return zaposleni;
    }
    
    
    
}

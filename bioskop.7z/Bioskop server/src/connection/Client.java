/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connection;

import domain.Zaposleni;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import transfer.Operation;
import transfer.Request;
import transfer.Response;
import transfer.ResponseStatus;

import SO.ObrisiFilm;
import SO.ObrisiProjekciju;
import SO.ObrisiSalu;
import SO.Prijava;
import SO.PronadjiFilmove;
import SO.PronadjiProjekcije;
import SO.SistemskaOperacija;
import SO.UcitajDistributere;
import SO.UcitajFilmove;
import SO.UcitajKarte;
import SO.UcitajProjekcije;
import SO.UcitajSale;
import SO.UcitajZanrove;
import SO.ZapamtiFilm;
import SO.ZapamtiKartu;
import SO.ZapamtiProjekciju;
import SO.ZapamtiSalu;
import domain.DomenskiObjekat;

/**
 *
 * @author milos
 */
public class Client extends Thread{

    private Zaposleni zaposleni = null;    
    private Socket soket;
    private Server server;
    private ObjectInputStream in;
    private ObjectOutputStream out;

    public Client(Socket soket, Server server) {
        this.soket = soket;
        this.server = server;
        try {
            in = new ObjectInputStream(soket.getInputStream());
            out = new ObjectOutputStream(soket.getOutputStream());
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        
    }

    @Override
    public void run() {
        try{//hvata IO
             while(true){
                 
                Request request = (Request) in.readObject();
                Response response = null;
                                               
                try{//hvata validation i sql                    
                    response = handleRequest(request);
                }
                catch(Exception e){
                    if(e instanceof IOException)//u slicaju da je prekid veze
                        throw e;
                    
                    response = new Response();
                    response.setErrorMessage(e.getMessage());
                    response.setStatus(ResponseStatus.ERROR);
                    e.printStackTrace();
                }                               
                out.writeObject(response);                            
             }
                
            } catch (Exception ex) { //hvata IOException              
                System.out.println("Konekcija sa klijentom je prekinuta.");
            }        
    }
    
    private Response handleRequest(Request request) throws Exception{
        Response response = new Response();
        SistemskaOperacija so = null;
                
        switch(request.getOperation()){    
            case prijava:
                so = new Prijava();
                Zaposleni z = (Zaposleni) request.getData();
                
                if(server.isLogged(z.getUsername()))               
                    throw new Exception("Ovaj korisnik je već prijavljen");
                
                break;
            case ucitajZanrove:
                so = new UcitajZanrove();
                break;
            case zapamtiFilm: 
                so = new ZapamtiFilm();
                break;                            
            case obrisiFilm:
                so = new ObrisiFilm();
                break;
            case ucitajDistributere:
                so = new UcitajDistributere();
                break;
            case ucitajSale:
                so = new UcitajSale();
                break;
            case obrisiSalu:
                so = new ObrisiSalu();
                break;
            case zapamtiSalu:
                so = new ZapamtiSalu();
                break;
            case ucitajFilmove:
                so = new UcitajFilmove();
                break;
            case zapamtiProjekciju:
                so = new ZapamtiProjekciju();
                break;
            case ucitajProjekcije:
                so = new UcitajProjekcije();
                break;
            case pronadjiFilmove:
                so = new PronadjiFilmove();
                break;
            case pronadjiProjekcije:
                so = new PronadjiProjekcije();
                break;
            case obrisiProjekciju:
                so = new ObrisiProjekciju();
                break;
            case ucitajKarte:
                so = new UcitajKarte();
                break;
            case zapamtiKartu:
                so = new ZapamtiKartu();             
        }
              
        if(request.getOperation() == Operation.prijava){
            zaposleni = (Zaposleni) so.izvrsi((DomenskiObjekat) request.getData());
            response.setData(zaposleni);
        }
        else if(zaposleni != null){//samo ulogovan korisnik moze da poziva ostale operacije
            Object result = so.izvrsi((DomenskiObjekat) request.getData());
            response.setData(result);
        }
        
        response.setStatus(ResponseStatus.SUCCESS);
        
        return response;
    }
    
    public void stopClient(){
        try {
            if(soket != null)
                soket.close();
            
        } catch (IOException ex) { }
    }

    public Zaposleni getZaposleni() {
        return zaposleni;
    }
        
}

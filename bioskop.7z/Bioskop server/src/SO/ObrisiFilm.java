/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SO;

import database.DBBroker;
import domain.Film;
import domain.PripadnostZanru;
import domain.Projekcija;
import domain.Zanr;
import exception.ValidationException;

/**
 *
 * @author milos
 */
public class ObrisiFilm extends SistemskaOperacija{

    @Override
    protected Object izvrsi() {
        Film film = (Film)objekat;
        
        for(Zanr z : film.getZanrovi()){//brise zanrove filma
            PripadnostZanru ps = new PripadnostZanru(z.getId(),film.getId());
            DBBroker.getInstance().obrisiSlog(ps);
        }
        
        DBBroker.getInstance().obrisiSlog(film);
        
        return null;              
    }

    @Override
    protected void validate() throws ValidationException {
        if(objekat == null)
            throw new ValidationException("Object is null");
        if(!(objekat instanceof  Film))
            throw new ValidationException("Invalid type");
               
        Projekcija projekcija = new Projekcija();
        projekcija.setFilm((Film) objekat);
 
        if(!DBBroker.getInstance().ucitajListuPoUslovu(projekcija).isEmpty())//proverava da li postoji projekcija za ovaj film
            throw new ValidationException("Sistem ne može da obriše film za koji postoji projekcija.");
    }
    
    
}

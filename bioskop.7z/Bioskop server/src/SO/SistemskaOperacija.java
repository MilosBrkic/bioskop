/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SO;

import database.DBBroker;
import domain.DomenskiObjekat;
import exception.ValidationException;
import java.sql.SQLException;

/**
 *
 * @author milos
 */
public abstract class SistemskaOperacija {
    
    protected DomenskiObjekat objekat;
     
    public Object izvrsi(DomenskiObjekat objekat) throws Exception{
        try {
            this.objekat = objekat;
            validate();
            Object rezultat = izvrsi();
            DBBroker.getInstance().commit();
            return rezultat;
        } catch (SQLException ex) {
            DBBroker.getInstance().rollback();
            throw ex;
        }
    }
    
    protected abstract void validate() throws ValidationException;    
    protected abstract Object izvrsi();   
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SO;

import database.DBBroker;
import domain.Karta;
import domain.Projekcija;
import exception.ValidationException;

/**
 *
 * @author milos
 */
public class UcitajKarte extends SistemskaOperacija{

    @Override
    protected Object izvrsi() {
        Projekcija projekcija = (Projekcija) objekat;
        Karta uslov = new Karta();
        uslov.setProjekcija(projekcija);
        
        return DBBroker.getInstance().ucitajListuPoUslovu(uslov);
    }

    @Override
    protected void validate() throws ValidationException {
        if(objekat == null)
            throw new ValidationException("Object is null");
        if(!(objekat instanceof  Projekcija))
            throw new ValidationException("Invalid type");
    }
    
}

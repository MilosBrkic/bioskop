/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SO;

import common.CommonFunctions;
import database.DBBroker;
import domain.DomenskiObjekat;
import domain.Projekcija;
import exception.ValidationException;
import java.time.LocalTime;
import java.util.LinkedList;

/**
 *
 * @author milos
 */
public class ZapamtiProjekciju extends SistemskaOperacija{

    @Override
    protected Object izvrsi() {
        Projekcija projekcija = (Projekcija) objekat;
        
        if(projekcija.getId() == 0){//nova projekcija
            DBBroker.getInstance().upisiSlog(projekcija);
        }
        else{
            DBBroker.getInstance().azurirajSlog(projekcija);                               
        }               
        return null;
    }

    @Override
    protected void validate() throws ValidationException {
        if(objekat == null)
            throw new ValidationException("Object is null");
        if(!(objekat instanceof  Projekcija))
            throw new ValidationException("Invalid type");
        
        Projekcija projekcija = (Projekcija) objekat;
        
        if(projekcija.getFilm() == null)
            throw new ValidationException("Film nije unet");
        
        if(DBBroker.getInstance().ucitajSlog(projekcija.getFilm()) == null)
            throw new ValidationException("Nepostojući film.");
        
        if(!projekcija.getFilm().isAktivan())
            throw new ValidationException("Izabrani film trenutno nije aktivan.");
        
        if(projekcija.getSala() == null)
            throw new ValidationException("Sala nije uneta");
        
        if(DBBroker.getInstance().ucitajSlog(projekcija.getSala()) == null)
            throw new ValidationException("Nepostojuća sala.");
        
        if(projekcija.getDatum() == null || projekcija.getVreme() == null)
            throw new ValidationException("Nisu uneti datum i vreme.");
        
        if(CommonFunctions.isInPast(projekcija))
            throw new ValidationException("Uneti datum ne može biti u prošlosti");
        
        
        LinkedList<DomenskiObjekat> lista = DBBroker.getInstance().ucitajListuPoUslovu(projekcija);//lista projekcija u istoj sali istog datuma
        
        
        for(DomenskiObjekat o : lista){//proverava da li se vreme projekcije poklapa sa drugom projekcijom
            Projekcija p = (Projekcija) o;
            
            if(p.getId() == projekcija.getId())//u slucaju azuriranja nece ga porediti sa samim sobom
                continue;
            
            DBBroker.getInstance().ucitajSlog(p.getFilm());
            
            LocalTime a = p.getVreme().toLocalTime();//pocetak i kraj projekcije sa kojom poredimo            
            LocalTime b = a.plusMinutes(p.getFilm().getTrajanje());
           
            LocalTime pocetak = projekcija.getVreme().toLocalTime();//pocetak i kraj projekcije koju ubacujemo            
            LocalTime kraj = pocetak.plusMinutes(p.getFilm().getTrajanje());
                      
            if(a.isBefore( kraj ) && b.isAfter( pocetak ))
                throw new ValidationException("Već postoji projekcija u ovoj sali u ovo vreme");                    
        }
            
        
    }
    
}

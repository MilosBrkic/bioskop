/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SO;

import common.CommonFunctions;
import database.DBBroker;
import domain.DomenskiObjekat;
import domain.Film;
import domain.PripadnostZanru;
import domain.Projekcija;
import domain.Zanr;
import exception.ValidationException;
import java.util.LinkedList;

/**
 *
 * @author milos
 */
public class ZapamtiFilm extends SistemskaOperacija{

    @Override
    protected Object izvrsi() {
        Film film = (Film)objekat;
        
        if(film.getId() == 0){//nov film
            DBBroker.getInstance().upisiSlog(film); 
            
            for(Zanr z : film.getZanrovi()){//dodavanje zanrova
                PripadnostZanru ps = new PripadnostZanru(z.getId(), film.getId());;
                DBBroker.getInstance().upisiSlog(ps);
            }
        }
        else{//azururanje
            
            Film stari =  new Film();
            stari.setId(film.getId());
            DBBroker.getInstance().ucitajSlog(stari);
            
            LinkedList<DomenskiObjekat> vezeZanr = DBBroker.getInstance().ucitajListuPoUslovu(new PripadnostZanru(0, stari.getId()));
            
            for(DomenskiObjekat o : vezeZanr){//prolazi kroz veze starih zanrova
                PripadnostZanru pz = (PripadnostZanru) o;
                boolean match = false;
                for(Zanr z : film.getZanrovi()){//prolazi kroz nove zanrove                  
                    if(pz.getZanrID() == z.getId())
                        match = true;
                }
                if(!match)//ukoliko stari zanr nije medju novima, brise se
                    DBBroker.getInstance().obrisiSlog(o);
            }
            DBBroker.getInstance().azurirajSlog(film);
            
            for(Zanr z : film.getZanrovi()){//dodavanje zanrova
                boolean match = false;
                for(DomenskiObjekat o : vezeZanr){
                    PripadnostZanru pz = (PripadnostZanru) o;
                    if(pz.getZanrID() == z.getId())
                        match = true;
                }
                if(!match){//ukoliko novi nije vec upusan, dodaje ga
                    PripadnostZanru ps = new PripadnostZanru(z.getId(), film.getId());;
                    DBBroker.getInstance().upisiSlog(ps);
                }
            }
        }
        
        
        
        return null;
    }

    @Override
    protected void validate() throws ValidationException {
        if(objekat == null)
            throw new ValidationException("Object is null");
        if(!(objekat instanceof  Film))
            throw new ValidationException("Invalid type");
        
        Film film = (Film) objekat;
        
        if(film.getNaziv().isEmpty())
             throw new ValidationException("Neispravan naziv");
        
        LinkedList<DomenskiObjekat> svi = DBBroker.getInstance().ucitajListu(new Film());
        for(DomenskiObjekat o : svi){//provera jednistvenosti naziva filma
            Film f = (Film) o;
            if(f.getId() != film.getId() && f.getNaziv().equals(film.getNaziv()))
                throw new ValidationException("Već postoji film sa istim nazivom.");
        }
            
        
        if(film.getTrajanje() <= 0)
             throw new ValidationException("Neispravno trajanje");
        
        if(film.getDistributer() == null)
            throw new ValidationException("Distributer nije unet");

        if(film.getZanrovi() == null || film.getZanrovi().isEmpty())
            throw new ValidationException("Mora biti unet bar jedan žanr");
        
        //za azuriranje
        Projekcija projekcije = new Projekcija();
        projekcije.setFilm(film);
        
        LinkedList<DomenskiObjekat> sve = DBBroker.getInstance().ucitajListuPoUslovu(projekcije);//sve projekcija za ovaj film
        LinkedList<DomenskiObjekat> buduce = new LinkedList<>();//projekcije u buducnosti
        
        
        for(DomenskiObjekat p : sve)
            if(!CommonFunctions.isInPast((Projekcija) p))
                buduce.add(p);
                
        
        if(!buduce.isEmpty()){//ukoliko postoje projekcije za ovaj film

            Film stari = new Film();
            stari.setId(film.getId());
            DBBroker.getInstance().ucitajSlog(stari);

            if(stari != null && stari.getTrajanje() < film.getTrajanje())
                throw new ValidationException("Ovaj film se koristi u projekcijama i povaćavanjem vremna trajanja filma može doći sa poklapanjam sa drugim projekcijama.");
            
            if(!film.isAktivan())
                throw new ValidationException("Film koji će se prikazivati na projekcijama ne može biti neaktivan.");
        }
        
    }
       
}

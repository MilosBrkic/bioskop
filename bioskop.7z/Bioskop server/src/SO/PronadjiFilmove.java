/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SO;

import database.DBBroker;
import domain.DomenskiObjekat;
import domain.Film;
import domain.PripadnostZanru;
import domain.Zanr;
import exception.ValidationException;
import java.util.LinkedList;

/**
 *
 * @author milos
 */
public class PronadjiFilmove extends SistemskaOperacija{

    @Override
    protected Object izvrsi() {

        Film uslov = (Film) objekat;
        
        LinkedList<DomenskiObjekat> filmovi = DBBroker.getInstance().ucitajListuPoUslovu(uslov);
        for(DomenskiObjekat o : filmovi){
            Film film = (Film)o;

            DBBroker.getInstance().ucitajSlog(film.getDistributer());//ubacuje distributera
                     
            LinkedList<DomenskiObjekat> vezeZanr = DBBroker.getInstance().ucitajListuPoUslovu(new PripadnostZanru(0, film.getId()));//ucitava pripadosti zanru
            
            LinkedList<Zanr> zanrovi = new LinkedList<>();
            
            for(DomenskiObjekat z : vezeZanr){
                PripadnostZanru ps = (PripadnostZanru)z;
               
                Zanr zanr = new Zanr();
                zanr.setId(ps.getZanrID());
                 
                DBBroker.getInstance().ucitajSlog(zanr);
                zanrovi.add(zanr);
                
            }
            film.setZanrovi(zanrovi);            
        }       
        return filmovi;
    }

    @Override
    protected void validate() throws ValidationException {
        if(objekat == null)
            throw new ValidationException("Object is null");
        if(!(objekat instanceof  Film))
            throw new ValidationException("Invalid type");       
    }
    
}

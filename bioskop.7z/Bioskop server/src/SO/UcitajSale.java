/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SO;

import database.DBBroker;
import domain.Sala;
import exception.ValidationException;

/**
 *
 * @author milos
 */
public class UcitajSale extends SistemskaOperacija{

    @Override
    protected Object izvrsi() {
        return DBBroker.getInstance().ucitajListu(new Sala());
    }

    @Override
    protected void validate() throws ValidationException {
        //nema validacije
    }

  
    
}

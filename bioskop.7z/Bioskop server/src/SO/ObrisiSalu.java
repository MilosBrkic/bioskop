/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SO;

import database.DBBroker;
import domain.DomenskiObjekat;
import domain.Projekcija;
import domain.Sala;
import exception.ValidationException;
import java.util.LinkedList;

/**
 *
 * @author milos
 */
public class ObrisiSalu extends SistemskaOperacija{

    @Override
    protected Object izvrsi() {            
        DBBroker.getInstance().obrisiSlog(objekat);
        return null;
    }

    @Override
    protected void validate() throws ValidationException {
        if(objekat == null)
            throw new ValidationException("Object is null");
        if(!(objekat instanceof  Sala))
            throw new ValidationException("Invalid type");
        
        Sala sala = (Sala) objekat;
        
        Projekcija projekcija = new Projekcija();
        projekcija.setSala(sala);
 
        if(!DBBroker.getInstance().ucitajListuPoUslovu(projekcija).isEmpty())//proverava da li postoji projekcija za ovu salu
            throw new ValidationException("Sistem ne može da obriše salu u kojoj postoji projekcija.");
               
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SO;

import database.DBBroker;
import domain.DomenskiObjekat;
import domain.Projekcija;
import exception.ValidationException;
import java.util.LinkedList;

/**
 *
 * @author milos
 */
public class PronadjiProjekcije extends SistemskaOperacija{

    @Override
    protected Object izvrsi() {
        Projekcija uslov = (Projekcija) objekat;
        
        LinkedList<DomenskiObjekat> projekcije = DBBroker.getInstance().ucitajListuPoUslovu(uslov);
        
        for(DomenskiObjekat o : projekcije){
            Projekcija pro = (Projekcija) o;
            
            DBBroker.getInstance().ucitajSlog(pro.getFilm());//u film koji ima samo id popunjava ostale atribute
            DBBroker.getInstance().ucitajSlog(pro.getSala());            
        }
                     
        return projekcije;
    }

    @Override
    protected void validate() throws ValidationException {
        if(objekat == null)
            throw new ValidationException("Object is null");
        if(!(objekat instanceof  Projekcija))
            throw new ValidationException("Invalid type");
        
        Projekcija projekcija = (Projekcija) objekat;
        if(projekcija.getFilm() == null)
            throw new ValidationException("Invalid condition");
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SO;

import common.CommonFunctions;
import database.DBBroker;
import domain.Karta;
import exception.ValidationException;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.Calendar;

/**
 *
 * @author milos
 */
public class ZapamtiKartu extends SistemskaOperacija{

    @Override
    protected Object izvrsi() {
        DBBroker.getInstance().upisiSlog(objekat);
        return null;
    }

    @Override
    protected void validate() throws ValidationException {
        if(objekat == null)
            throw new ValidationException("Object is null");
        if(!(objekat instanceof  Karta))
            throw new ValidationException("Invalid type");
        
        Karta karta = (Karta) objekat;
        
        if(karta.getBrojReda() < 0 || karta.getBrojSedista() < 0)
            throw new ValidationException("Neispravno mesto");
        
        if(karta.getCena().compareTo(BigDecimal.ZERO) == -1)//cena < 0
            throw new ValidationException("Neispravna cena");
        
        if(karta.getProjekcija() == null)
            throw new ValidationException("Nije uneta projekcija");
        
        if(DBBroker.getInstance().ucitajSlog(karta.getProjekcija()) == null)
            throw new ValidationException("Nepostojeća projekcija.");
        //if(karta.getBrojReda()*karta.getBrojSedista() > karta.getProjekcija().getSala().getBrojSedista())//da li sediste postoji u sali
            //throw new ValidationException("Neispravno mesto");
        
        if(DBBroker.getInstance().ucitajSlog(karta) != null)
            throw new ValidationException("Karta za ovo mesto je već prodata");
        
       /* Date danas = new Date(new java.util.Date().getTime());//danas
        
        Calendar dateCal = Calendar.getInstance();
        dateCal.setTime(karta.getProjekcija().getDatum());
        Calendar timeCal = Calendar.getInstance();
        timeCal.setTime(karta.getProjekcija().getVreme());
        
        dateCal.set(Calendar.HOUR_OF_DAY, timeCal.get(Calendar.HOUR_OF_DAY));
        dateCal.set(Calendar.MINUTE, timeCal.get(Calendar.MINUTE));
 
        Date date = new Date(dateCal.getTime().getTime());//datum i vreme projekcije*/
        
        if(CommonFunctions.isInPast(karta.getProjekcija()))
            throw new ValidationException("Karta se ne može prodati za projekciju koja je prošla");
    }
    
}

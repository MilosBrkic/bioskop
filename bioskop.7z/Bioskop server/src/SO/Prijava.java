/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SO;

import database.DBBroker;
import domain.Zaposleni;
import exception.ValidationException;

/**
 *
 * @author milos
 */
public class Prijava extends SistemskaOperacija{

    @Override
    protected Object izvrsi() {
        return DBBroker.getInstance().ucitajSlog(objekat);
    }

    @Override
    protected void validate() throws ValidationException {
        if(objekat == null)
            throw new ValidationException("Object is null");
        if(!(objekat instanceof  Zaposleni))
            throw new ValidationException("Invalid type");
        
        Zaposleni zaposleni = (Zaposleni) objekat;
        
        if(zaposleni.getUsername() == null || zaposleni.getUsername().isEmpty())
            throw new ValidationException("Username mora biti unet");
        
        if(zaposleni.getPassword() == null || zaposleni.getPassword().isEmpty())
            throw new ValidationException("Password mora biti unet");
    }
    
}

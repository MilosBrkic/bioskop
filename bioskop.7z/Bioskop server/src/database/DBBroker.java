/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;


import domain.DomenskiObjekat;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author milos
 */
public class DBBroker {
    
    private Connection connection;
    private static DBBroker instance;

    private DBBroker(){    
        try {
            FileInputStream in = new FileInputStream("database.properties");
            Properties properties = new Properties();
            properties.load(in);
            in.close();
            
            String url = properties.getProperty("url");
            String user = properties.getProperty("user");
            String password = properties.getProperty("password");
            
            connection = DriverManager.getConnection(url, user, password);   
            connection.setAutoCommit(false);
        } catch (Exception ex) {
            //JOptionPane.showMessageDialog(null, "a"+ex.getMessage(), "Greška", JOptionPane.ERROR_MESSAGE);
        }                        
    }
    
    public static DBBroker getInstance(){
        if(instance == null)
           instance = new DBBroker();
                              
        return instance;
    }
    
    public synchronized DomenskiObjekat upisiSlog(DomenskiObjekat objekat){
        
        String query = "INSERT INTO "+objekat.getNazivTabele()+" "+objekat.getKolone()+" VALUES"+objekat.getVrednostiAtributa();
        System.out.println(query);
        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate(query, Statement.RETURN_GENERATED_KEYS);
            ResultSet rs = statement.getGeneratedKeys();
            if (rs.next()) {
                int id = rs.getInt(1);
                objekat.setId(id);
            }
            return objekat;
        } catch (SQLException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public synchronized void obrisiSlog(DomenskiObjekat objekat){
        String query = "DELETE FROM "+objekat.getNazivTabele()+" WHERE "+objekat.uslovIdentifikacije();
        System.out.println(query);
        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate(query);        
        } 
        catch (SQLException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);//todo
        }
    }
    
    public DomenskiObjekat ucitajSlog(DomenskiObjekat objekat){
        String query = "SELECT * FROM "+objekat.getNazivTabele()+" WHERE "+objekat.uslovIdentifikacije();
        System.out.println(query);
         try {
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(query);
            if(rs.next()){
                
                objekat.postaviVrednosti(rs);
                return objekat;
            }
        } 
        catch (SQLException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);//todo
        }
        return null;
    }
    
    public LinkedList<DomenskiObjekat> ucitajListu(DomenskiObjekat objekat){//ucitava listu svih objekata tipa ulaznong parametra
        LinkedList<DomenskiObjekat> lista = new LinkedList<>();
        String query = "SELECT * FROM "+objekat.getNazivTabele();
        System.out.println(query);
        try {
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(query);
            while(rs.next()){
                DomenskiObjekat o = objekat.getClass().newInstance();
                o.postaviVrednosti(rs);
                lista.add(o);
            }
        } 
        catch (SQLException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);//todo
        } catch (InstantiationException ex) {  
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return lista;
    }
    
    public LinkedList<DomenskiObjekat> ucitajListuPoUslovu(DomenskiObjekat objekat){
        LinkedList<DomenskiObjekat> lista = new LinkedList<>();                      
        String query = "SELECT * FROM "+objekat.getNazivTabele()+ " WHERE "+objekat.uslovPretrage();
        System.out.println(query);
        try {
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(query);
            while(rs.next()){
                
                DomenskiObjekat o = objekat.getClass().newInstance();
                boolean t =  o.postaviVrednosti(rs);
                lista.add(o);
            }
        } 
        catch (SQLException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);//todo
        } catch (InstantiationException ex) {  
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return lista;
    }
    
    public synchronized void azurirajSlog(DomenskiObjekat objekat){
        String query = "UPDATE "+objekat.getNazivTabele()+" SET "+objekat.uslovAzururanja()+" WHERE "+objekat.uslovIdentifikacije();
        System.out.println(query);
        try {
            Statement statement = connection.createStatement();
            statement.executeUpdate(query);
        } catch (SQLException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    }
    
     
    public synchronized void commit() throws SQLException{
        if(connection != null)
            connection.commit();
    }
    
    public synchronized void rollback() throws SQLException{
        if(connection != null)
            connection.rollback();
    }
    
    public static void close(){
        if(instance != null){
            try {
                if(instance.connection != null)
                    instance.connection.close();
                
                instance = null;
            } catch (Exception ex) {
                Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public boolean checkConnection(){//proverava da li postoji veza sa bazom
        return connection != null;
    }
    
}
